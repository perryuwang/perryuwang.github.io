﻿(function(d, s, id) {
	var iframe;
	if (d.getElementById(id)) return;
	iframe = d.createElement(s);
	iframe.id = id;
	iframe.src = "//r.dmp.sina.cn/cm/sinaads_ck_wap.html";
	iframe.style.display = 'none';
	d.body.appendChild(iframe);
})(document, 'iframe', 'sinaads-ck-iframe');